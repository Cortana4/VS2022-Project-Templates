#include <iostream>

int main(int argC, char* argV[])
{
	std::cout << "Hello World!" << std::endl;
	return 0;
}
